import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MongoClient cliente= new MongoClient();
		MongoDatabase db=cliente.getDatabase("libros_evaluable");
		MongoCollection<Document> coleccion=db.getCollection("libros");
		
		Scanner sc= new Scanner(System.in);
		int op=sc.nextInt();
		switch (op) {
		case 1: {
			System.out.println("1.	Mostrar el título de los libros que tienen entre 200 y 400 páginas publicadas antes de 1900.");
			List<Document> l = coleccion.find(Filters.and(Filters.gte("paginas", 200),Filters.lte("paginas", 400),Filters.lt("publicacion", 1900))).into(new ArrayList<>());
			for (Document document : l) {
				String titulo=document.getString("titulo");
				Double paginas=document.getDouble("paginas");
				Double publicacion=document.getDouble("publicacion");
				
				System.out.println(titulo+"- "+paginas+" -"+publicacion);
			}
			break;
		}
		case 2:{
			System.out.println("2.	Mostrar el autor de los libros publicados en español.");
			List<Document> l =coleccion.find(Filters.eq("idioma", "Español")).into(new ArrayList<>());
			for (Document document : l) {
				String autor=document.getString("autor");
				System.out.println(autor);
			}
			break;
		}
		case 3:{
			System.out.println("3.	Mostrar el título de los libros publicados en el año 1949, 1954 o 1960.");
			List<Document> l = coleccion.find(Filters.in("publicacion", 1949,1954,1960)).into(new ArrayList<>());
			for (Document document : l) {
				String titulo=document.getString("titulo");
				Double publicacion = document.getDouble("publicacion");
				System.out.println(titulo+"-"+publicacion);
			}
			break;
		}
		case 4:{
				System.out.println("4.	Mostrar el título de los libros de las novelas que son góticas o históricas, que no están publicados en ruso");
				List<Document> l = coleccion.find(Filters.and(Filters.in("genero", "Novela gótica","Novela histórica"),Filters.ne("idioma", "Ruso"))).into(new ArrayList<>());
				for (Document document : l) {
					String titulo=document.getString("titulo");
					String genero=document.getString("genero");
					
					
					System.out.println(titulo+"-"+genero);
				}
				break;
		}
		case 5:{
			System.out.println("5.	Añadir el idioma ruso a los libros que son novela y que tienen más de 1000 páginas.");
			UpdateResult up=coleccion.updateMany(Filters.and(Filters.eq("genero", "Novela"),Filters.gt("paginas", 1000)),Updates.addToSet("idioma", "Ruso"));
			System.out.println("MOD: "+ up.getModifiedCount());
			break;
		}
		case 6:{
			System.out.println("6.	Quitar 5 páginas a los libros de novela de aventuras.");
			
			UpdateResult up=coleccion.updateMany(Filters.eq("genero", "Novela de aventuras"),Updates.inc("paginas", -5) );
			System.out.println("MOD: "+up.getModifiedCount());
			
			break;
		}
		case 7:{
			
			DeleteResult del=coleccion.deleteMany(Filters.eq("disponible", false));
			System.out.println("BORRADOS: "+del.getDeletedCount());
		}
		default:
			break;
		}
	}

}
