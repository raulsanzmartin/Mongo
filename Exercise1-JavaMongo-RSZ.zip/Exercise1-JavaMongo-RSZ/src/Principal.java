import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MongoClient cliente= new MongoClient();
		MongoDatabase db=cliente.getDatabase("ad_recuperacion");
		MongoCollection<Document>coleccion=db.getCollection("empleados");
		
		Scanner sc= new Scanner(System.in);
		int op=sc.nextInt();
		switch (op) {
		case 1: {
			System.out.println(" Mostrar el nombre, departamento y salarioAnual de cada "
					+ "empleado. El salarioAnual se calcula multiplicando el salarioAnual por 14");
			List<Document> l = coleccion.find().into(new ArrayList<>());
			for (Document document : l) {
				String nombre=document.getString("nombre");
				Double dep=document.getDouble("dep");
				Double salario=document.getDouble("salario");
				
				System.out.println(nombre+" "+dep+" SAL ANUAL: "+salario*14);
			}
			
			break;
		}
		case 2:{
			System.out.println("Si el empleado tiene oficio, mostrar el nombre y oficio");
			List<Document> l =coleccion.find(Filters.exists("oficio")).into(new ArrayList<>());
			for (Document document : l) {
				String nombre=document.getString("nombre");
				String oficio=document.getString("oficio");
				System.out.println("NOMBRE: "+nombre+" OFICIO: "+oficio);
			}
			break;
		}
		case 3:{
			System.out.println("3.Mostrar a quién más cobra.");
			List<Document> l = coleccion.find().sort(Sorts.descending("salario")).limit(1).into(new ArrayList<>());
			for (Document document : l) {
				String nombre=document.getString("nombre");
				Double salario=document.getDouble("salario");
				
				System.out.println(nombre+" "+salario);
			}
			
			break;
		}
		case 4:{
			System.out.println("Mostrar los analistas que están en el departamento 20 o\r\n"
					+ "30, y cuyo salario está entre 1000€ y 5000€.");
			
			List<Document> l = coleccion.find(Filters.and(Filters.in("dep", 20,30),Filters.lte("salario", 5000),Filters.gte("salario", 1000))).into(new ArrayList<>());
			for (Document document : l) {
				String nombre=document.getString("nombre");
				Double dep=document.getDouble("dep");
				Double salario=document.getDouble("salario");
				System.out.println(nombre+" "+dep+" "+salario);
			}
			break;
		}
		case 5:{
			System.out.println("Subir el salario a 1200€ a todos los que cobren menos.");
			UpdateResult up = coleccion.updateMany(Filters.lt("salario", 1200), Updates.addToSet("salario", 1200));
			
			break;
		}
		case 6:{
			System.out.println("Eliminar a los empleados cuyo oficio es Profesora");
			DeleteResult del= coleccion.deleteMany(Filters.eq("oficio", "Profesora"));
			break;
		}
		case 7:{
			List<Document> pipeline=Arrays.asList(new Document("$group",new Document("_id","$dep").append("media", new Document("$avg","$salario")).append("suma", new Document("$sum",1))));
			
			
			MongoIterable<Document> res=coleccion.aggregate(pipeline);
			for (Document document : res) {
				Object id= document.get("_id");
				Double media=document.getDouble("media");
				int suma=document.getInteger("suma");
				
				System.out.println(id+" "+media+" "+suma);
			}
			
			
		}
		default:
			System.out.println("OPCION INRRECTA");
		}
	}

}
