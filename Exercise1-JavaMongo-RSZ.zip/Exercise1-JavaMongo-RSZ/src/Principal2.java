import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.UpdateResult;

public class Principal2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MongoClient cliente= new MongoClient();
		MongoDatabase db=cliente.getDatabase("ad_libros");
		MongoCollection<Document>coleccion=db.getCollection("libros");
		
		Scanner sc= new Scanner(System.in);
		int op=sc.nextInt();
		switch (op) {
		case 1:{
			System.out.println("Consultar los libros que están disponibles, con género novela romántica\r\n"
					+ "o novela gótica y tienen entre 200 y 400 páginas (incluidas). Mostrar sólo\r\n"
					+ "el título y el autor");
			
			List<Document> l = coleccion.find(Filters.and(Filters.eq("disponible", true),Filters.in("genero", "Novela romántica","Novela gótica"),Filters.gte("paginas", 200),Filters.lte("paginas", 400))).into(new ArrayList<>());
			
			for (Document document : l) {
				String titulo=document.getString("titulo");
				String genero=document.getString("genero");
				Double paginas=document.getDouble("paginas");
				
				System.out.println(titulo+" "+genero+" "+paginas);
				
			}
			break;
		}
		case 2:{
			System.out.println("Añadir el idioma alemán, si no lo tienen ya, a los libros posteriores a 1930");
			UpdateResult up= coleccion.updateMany(Filters.ne("idioma","Aleman"), Updates.addToSet("idioma", "Alemán"));
			System.out.println("mod:"+up.getModifiedCount());
			break;
		}
		case 3:{
			System.out.println("Mostrar los títulos de las películas cuyo título empieza por “El”");
			List<Document> l = coleccion.find().into(new ArrayList<>());
			for (Document document : l) {
				String titulo=document.getString("titulo");
				if (titulo.startsWith("El")) {
					System.out.println(titulo);
				}
			}
			break;
		}
		case 4:{
			System.out.println("Mostrar la media de páginas del género novela gótica");
			
			List<Document> l= Arrays.asList(new Document("$group", new Document("_id","$genero").append("media", new Document("$avg","$paginas"))));
			MongoIterable<Document> ite=coleccion.aggregate(l);
			for (Document document : ite) {
				Object gen=document.get("_id");
				if (gen.equals("Novela gótica")) {
					Double media =document.getDouble("media");
					System.out.println(gen+" "+media);
				}
			}
			
			break;
		}
		case 5:{
			System.out.println("Mostrar los títulos de las películas ordenadas por año descendente.");
			List<Document> l = coleccion.find().sort(Sorts.descending("publicacion")).into(new ArrayList<>());
			for (Document document : l) {
				String titlo=document.getString("titulo");
				Double publi=document.getDouble("publicacion");
				System.out.println(titlo+" "+publi);
			}
			break;
		}
		case 6:{
			System.out.println("Mostrar los títulos de las películas junto con el precio por página (dividir el\r\n"
					+ "precio entre el número de páginas).");
			List<Document> l = coleccion.find().into(new ArrayList<>());
			for (Document document : l) {
				String titulo=document.getString("titulo");
				Double precio=document.getDouble("precio");
				Double paginas=document.getDouble("paginas");
				
				System.out.println(titulo+" "+precio/paginas);
			}
			break;
		}
		
		case 7:{
			System.out.println("Mostrar por cada categoría, el título libro con más páginas");
			
			List<Document> l = Arrays.asList(new Document("$group", new Document("_id","$genero").append("max", new Document("$max","$paginas"))));
			MongoIterable<Document> ite=coleccion.aggregate(l);
			for (Document document : ite) {
				Object id= document.get("_id");
				Double max=document.getDouble("max");
				System.out.println(id+" "+max);
			}
			break;
		}
		case 8:{
			System.out.println("Mostrar los títulos de los libros con las siguientes páginas: 417, 418, 672,\r\n"
					+ "863.");
			List<Document> l = coleccion.find(Filters.in("paginas", 417,418,67,863)).into(new ArrayList<>());
			for (Document document : l) {
				String titulo=document.getString("titulo");
				Double paginas=document.getDouble("paginas");
				System.out.println(titulo+" "+paginas);
			}
			break;
		}
		case 9:{
			System.out.println("Mostrar por cada categoría, el número de libros que hay y el número de\r\n"
					+ "páginas de todos ellos");
			
			List<Document> pipe=Arrays.asList(new Document("$group",new Document("_id","$genero").append("numli", new Document("$sum",1)).append("sumaPags", new Document("$sum","$paginas"))));
			MongoIterable<Document> ite=coleccion.aggregate(pipe);
			for (Document document : ite) {
				Object id=document.get("_id");
				int numli=document.getInteger("numli");
				Double sumaPags=document.getDouble("sumaPags");
				
				System.out.println(id+" "+numli+" "+sumaPags);
			}
			break;
		}
		case 10:{
			System.out.println("Mostrar los títulos de todos los libros y la editorial. En caso de no tener\r\n"
					+ "editorial, se mostrará “Desconocida”.");
			List<Document> l = coleccion.find().into(new ArrayList<>());
			for (Document document : l) {
				String titulo=document.getString("titulo");
				String editorial=document.getString("editorial");
				if (editorial==(null)) {
					System.out.println(titulo+" DESCONOCIDA");
				}
				else {
					System.out.println(titulo+" "+editorial);
				}
			}
			break;
		}
		case 11:{
			System.out.println("Mostrar los títulos de los libros junto con el tipoPrecio. El tipoPrecio se\r\n"
					+ "calculará según el siguiente criterio:\r\n"
					+ "• Si el precio es menor de 20€, se mostrará que es “barato”.\r\n"
					+ "• Si está entre 20 y 50 (incluidos), entonces es “medio”.\r\n"
					+ "• Si es mayor de 50 será “caro”.");
			List<Document> l= coleccion.find().into(new ArrayList<>());
			for (Document document : l) {
				String titulo=document.getString("titulo");
				Double precio=document.getDouble("precio");
				if (precio<20) {
					System.out.println(titulo+ " BARATO");
				}
				else if (precio>50) {
					System.out.println(titulo+" CARO");
				} else {
					System.out.println(titulo+ " MEDIO");
				}
			}
			break;
		}
		case 12:{
			System.out.println("Mostrar los títulos de los libros que tienen editorial.");
			List<Document> l = coleccion.find(Filters.exists("editorial")).into(new ArrayList<>());
			for (Document document : l) {
				String tit=document.getString("titulo");
				String edi=document.getString("editorial");
				
				System.out.println(tit+" "+edi);
			}
			break;
		}
		case 13:{
			System.out.println("Mostrar el autor de los libros publicados en español.");
			List<Document> l = coleccion.find(Filters.eq("idioma", "Español")).into(new ArrayList<>());
			for (Document document : l) {
				System.out.println(document.getString("autor"));
			}
			break;
		}
		//MIRAR
		/*case 14:{
			System.out.println("Mostrar los títulos de los libros que están disponibles y tienen exactamente 3 idiomas");
			List<Document> l = coleccion.find().into(new ArrayList<>());
			for (Document document : l) {
	            List<String> idiomas = document.getList("idioma", String.class);
	            if (idiomas != null && idiomas.size() == 3) {
	                String titulo = document.getString("titulo");
	                System.out.println(titulo);
	            }
	        }
			break;
		}*/
		case 15:{
			System.out.println("Mostrar los títulos de los libros cuyo precio sea mayor que el precio promedio de todos los libros.");
			Double media=0.0;
			List<Document> l = Arrays.asList(new Document("$group", new Document("_id",null).append("media", new Document("$avg","$precio")))) ;
			MongoIterable<Document> ite=coleccion.aggregate(l);
			
			for (Document document : ite) {
				
				 media=document.getDouble("media");
				
				System.out.println("MEDIA PRECIO: "+media);
			}
			
			List<Document> l2=coleccion.find().into(new ArrayList<>());
			for (Document document : l2) {
				String titulo=document.getString("titulo");
				Double precio=document.getDouble("precio");
				if (precio>media) {
					System.out.println(titulo+" "+precio);
				}
			}
			
			break;
		}
		case 16:{
			System.out.println("Consultar los libros que tienen exactamente 864 páginas. Mostrar sólo el título.");
			List<Document> l=coleccion.find(Filters.eq("paginas", 864)).into(new ArrayList<>());
			for (Document document : l) {
				String titulo=document.getString("titulo");
				Double paginas =document.getDouble("paginas");
				System.out.println(titulo+" "+paginas);
			}
		}
		
		
		
		default:
			break;
		}
	
	}

}
